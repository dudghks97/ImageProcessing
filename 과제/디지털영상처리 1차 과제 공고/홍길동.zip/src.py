# 아래 Path와 Name은 그대로 현재 설정을 사용해 주세요....
# 현재 d:/dip/dark1.png 파일을 입력 영상으로 사용하고 있습니다.
Path = 'd:/dip/'
Name = 'dark1.png'

